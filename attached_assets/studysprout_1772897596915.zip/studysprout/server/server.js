// server.js — StudySprout Express backend
// Serves the REST API and (in production) the built React app

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

import userRoutes    from './routes/users.js';
import petRoutes     from './routes/pets.js';
import sessionRoutes from './routes/sessions.js';
import testRoutes    from './routes/tests.js';
import wardrobeRoutes from './routes/wardrobe.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;

// ─── Middleware ────────────────────────────────────────────
app.use(cors());                          // allow Vite dev server requests
app.use(express.json());                  // parse JSON bodies

// ─── API Routes ────────────────────────────────────────────
app.use('/api/user',     userRoutes);
app.use('/api/pet',      petRoutes);
app.use('/api/session',  sessionRoutes);
app.use('/api/tests',    testRoutes);
app.use('/api/wardrobe', wardrobeRoutes);

// ─── Serve built React app in production ───────────────────
const clientDist = path.join(__dirname, '..', 'client', 'dist');
app.use(express.static(clientDist));
app.get('*', (req, res) => {
  res.sendFile(path.join(clientDist, 'index.html'));
});

// ─── Start ─────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🌱 StudySprout server running on http://localhost:${PORT}`);
});
