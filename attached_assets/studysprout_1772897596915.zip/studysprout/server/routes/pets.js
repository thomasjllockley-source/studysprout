// routes/pets.js — Pet selection and retrieval

import { Router } from 'express';
import db, { computeLevel, xpForNextLevel, LEVEL_THRESHOLDS } from '../database.js';

const router = Router();

const VALID_PET_TYPES = ['hamster', 'dog', 'cat', 'raccoon'];

// ─── POST /api/pet/select ──────────────────────────────────
// Called when user picks their starter pet.
// Only allowed if user doesn't already have a pet.
router.post('/select', (req, res) => {
  const { userId, petType } = req.body;

  if (!userId || !petType) {
    return res.status(400).json({ error: 'userId and petType are required' });
  }
  if (!VALID_PET_TYPES.includes(petType)) {
    return res.status(400).json({ error: `petType must be one of: ${VALID_PET_TYPES.join(', ')}` });
  }

  try {
    // Prevent multiple pets per user
    const existing = db.prepare('SELECT * FROM pets WHERE user_id = ?').get(userId);
    if (existing) {
      return res.json(existing);
    }

    const result = db.prepare(`
      INSERT INTO pets (user_id, pet_type, happiness, level, xp)
      VALUES (?, ?, 80, 1, 0)
    `).run(userId, petType);

    const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(pet);
  } catch (err) {
    console.error('Pet select error:', err);
    res.status(500).json({ error: 'Could not select pet' });
  }
});

// ─── GET /api/pet/:userId ──────────────────────────────────
// Returns the pet for a given user, enriched with level info.
router.get('/:userId', (req, res) => {
  const { userId } = req.params;

  try {
    const pet = db.prepare('SELECT * FROM pets WHERE user_id = ?').get(userId);
    if (!pet) {
      return res.status(404).json({ error: 'No pet found for this user' });
    }

    // Enrich with level progression data
    const nextLevelXp = xpForNextLevel(pet.level) ?? pet.xp;
    const prevLevelXp = LEVEL_THRESHOLDS[pet.level - 1] ?? 0;

    res.json({
      ...pet,
      nextLevelXp,
      prevLevelXp,
      xpProgress: pet.xp - prevLevelXp,
      xpNeeded: nextLevelXp - prevLevelXp,
    });
  } catch (err) {
    console.error('Get pet error:', err);
    res.status(500).json({ error: 'Could not fetch pet' });
  }
});

export default router;
