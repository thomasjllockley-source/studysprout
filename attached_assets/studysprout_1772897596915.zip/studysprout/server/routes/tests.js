// routes/tests.js — Upcoming test calendar management

import { Router } from 'express';
import db from '../database.js';

const router = Router();

// ─── POST /api/tests/create ────────────────────────────────
router.post('/create', (req, res) => {
  const { userId, subject, name, date } = req.body;

  if (!userId || !subject || !name || !date) {
    return res.status(400).json({ error: 'userId, subject, name, and date are required' });
  }

  try {
    const result = db.prepare(`
      INSERT INTO tests (user_id, subject, name, date)
      VALUES (?, ?, ?, ?)
    `).run(userId, subject, name, date);

    const test = db.prepare('SELECT * FROM tests WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(test);
  } catch (err) {
    console.error('Create test error:', err);
    res.status(500).json({ error: 'Could not create test' });
  }
});

// ─── GET /api/tests/:userId ────────────────────────────────
// Returns upcoming tests sorted by date ascending.
router.get('/:userId', (req, res) => {
  const { userId } = req.params;

  try {
    const tests = db.prepare(`
      SELECT * FROM tests
      WHERE user_id = ?
      ORDER BY date ASC
    `).all(userId);

    res.json(tests);
  } catch (err) {
    console.error('Get tests error:', err);
    res.status(500).json({ error: 'Could not fetch tests' });
  }
});

// ─── DELETE /api/tests/:id ─────────────────────────────────
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const result = db.prepare('DELETE FROM tests WHERE id = ?').run(id);
    if (result.changes === 0) {
      return res.status(404).json({ error: 'Test not found' });
    }
    res.json({ message: 'Test deleted' });
  } catch (err) {
    console.error('Delete test error:', err);
    res.status(500).json({ error: 'Could not delete test' });
  }
});

export default router;
