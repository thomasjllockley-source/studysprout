// routes/sessions.js — Study session lifecycle management

import { Router } from 'express';
import db, { computeLevel, LEVEL_THRESHOLDS } from '../database.js';

const router = Router();

// ─── POST /api/session/start ───────────────────────────────
// Creates a new study session record and returns the session ID.
router.post('/start', (req, res) => {
  const { userId, subject, duration } = req.body;

  if (!userId || !subject || !duration) {
    return res.status(400).json({ error: 'userId, subject, and duration are required' });
  }

  try {
    const result = db.prepare(`
      INSERT INTO study_sessions (user_id, subject, duration, completed, warnings, created_at)
      VALUES (?, ?, ?, 0, 0, datetime('now'))
    `).run(userId, subject, duration);

    res.status(201).json({ sessionId: result.lastInsertRowid });
  } catch (err) {
    console.error('Session start error:', err);
    res.status(500).json({ error: 'Could not start session' });
  }
});

// ─── POST /api/session/warning ─────────────────────────────
// Increments the warning count on a session.
// Returns the new warning count so the client can react.
router.post('/warning', (req, res) => {
  const { sessionId } = req.body;

  if (!sessionId) {
    return res.status(400).json({ error: 'sessionId is required' });
  }

  try {
    const session = db.prepare('SELECT * FROM study_sessions WHERE id = ?').get(sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    const newWarnings = session.warnings + 1;
    db.prepare('UPDATE study_sessions SET warnings = ? WHERE id = ?').run(newWarnings, sessionId);

    res.json({ warnings: newWarnings });
  } catch (err) {
    console.error('Session warning error:', err);
    res.status(500).json({ error: 'Could not record warning' });
  }
});

// ─── POST /api/session/complete ───────────────────────────
// Marks session as completed, awards XP + coins, updates streak.
router.post('/complete', (req, res) => {
  const { sessionId, userId } = req.body;

  if (!sessionId || !userId) {
    return res.status(400).json({ error: 'sessionId and userId are required' });
  }

  try {
    const session = db.prepare('SELECT * FROM study_sessions WHERE id = ?').get(sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const pet = db.prepare('SELECT * FROM pets WHERE user_id = ?').get(userId);
    if (!pet) return res.status(404).json({ error: 'Pet not found' });

    const minutes   = session.duration;
    const xpGained  = minutes * 5;
    const coinsGained = minutes * 2;

    // ── Update session as completed ──────────────────────
    db.prepare('UPDATE study_sessions SET completed = 1 WHERE id = ?').run(sessionId);

    // ── Calculate new streak ─────────────────────────────
    const today     = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    let newStreak = 1;
    if (user.last_study_date === today) {
      newStreak = user.streak;           // already studied today, no change
    } else if (user.last_study_date === yesterday) {
      newStreak = user.streak + 1;       // continued streak
    }

    // ── Update user coins + streak ───────────────────────
    db.prepare(`
      UPDATE users SET
        coins = coins + ?,
        streak = ?,
        last_study_date = ?
      WHERE id = ?
    `).run(coinsGained, newStreak, today, userId);

    // ── Update pet XP and level ──────────────────────────
    const newXp    = pet.xp + xpGained;
    const newLevel = computeLevel(newXp);
    const newHappy = Math.min(100, pet.happiness + 5);  // bonus happiness on success

    db.prepare(`
      UPDATE pets SET xp = ?, level = ?, happiness = ? WHERE user_id = ?
    `).run(newXp, newLevel, newHappy, userId);

    const leveledUp = newLevel > pet.level;

    res.json({
      xpGained,
      coinsGained,
      newStreak,
      leveledUp,
      newLevel,
      newXp,
      newHappy,
      message: generateEncouragement(pet.pet_type, minutes, newStreak),
    });
  } catch (err) {
    console.error('Session complete error:', err);
    res.status(500).json({ error: 'Could not complete session' });
  }
});

// ─── POST /api/session/fail ────────────────────────────────
// Marks session as failed, reduces pet happiness by 10.
router.post('/fail', (req, res) => {
  const { sessionId, userId } = req.body;

  if (!sessionId || !userId) {
    return res.status(400).json({ error: 'sessionId and userId are required' });
  }

  try {
    db.prepare('UPDATE study_sessions SET completed = 0 WHERE id = ?').run(sessionId);

    const pet = db.prepare('SELECT * FROM pets WHERE user_id = ?').get(userId);
    if (pet) {
      const newHappy = Math.max(0, pet.happiness - 10);
      db.prepare('UPDATE pets SET happiness = ? WHERE user_id = ?').run(newHappy, userId);
    }

    res.json({ message: 'Session failed. Your pet is a little sad. Try again!', newHappy: pet ? Math.max(0, pet.happiness - 10) : 0 });
  } catch (err) {
    console.error('Session fail error:', err);
    res.status(500).json({ error: 'Could not record session failure' });
  }
});

// ─── Encouragement message generator ──────────────────────
// Placeholder — can be replaced with a real AI call later
function generateEncouragement(petType, minutes, streak) {
  const petEmoji = { hamster: '🐹', dog: '🐶', cat: '🐱', raccoon: '🦝' }[petType] || '🐾';
  const petName  = petType.charAt(0).toUpperCase() + petType.slice(1);

  const messages = [
    `Your ${petName} ${petEmoji} is SO proud of your ${minutes} minutes of focus!`,
    `Amazing work! Your ${petName} did a happy dance for you! ${petEmoji}`,
    `${minutes} minutes down! Your ${petName} thinks you're incredible ${petEmoji}`,
    `Your ${petName} ${petEmoji} couldn't stop smiling watching you study!`,
    streak > 1
      ? `${streak} day streak! Your ${petName} ${petEmoji} is on fire! 🔥`
      : `Great start! Your ${petName} ${petEmoji} believes in you!`,
  ];

  return messages[Math.floor(Math.random() * messages.length)];
}

export default router;
