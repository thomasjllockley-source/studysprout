// routes/users.js — User creation and retrieval

import { Router } from 'express';
import db from '../database.js';

const router = Router();

// ─── POST /api/user/create ─────────────────────────────────
// Creates a new anonymous user and returns their record.
// Called on first app load; userId is stored in localStorage.
router.post('/create', (req, res) => {
  const { id } = req.body;

  if (!id) {
    return res.status(400).json({ error: 'User ID is required' });
  }

  try {
    // Check if user already exists (idempotent)
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (existing) {
      return res.json(existing);
    }

    // Insert new user with defaults
    db.prepare(`
      INSERT INTO users (id, coins, streak, last_study_date, created_at)
      VALUES (?, 0, 0, NULL, datetime('now'))
    `).run(id);

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    res.status(201).json(user);
  } catch (err) {
    console.error('Create user error:', err);
    res.status(500).json({ error: 'Could not create user' });
  }
});

// ─── GET /api/user/:id ─────────────────────────────────────
// Returns user data including their pet and upcoming tests.
router.get('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ error: 'Could not fetch user' });
  }
});

export default router;
