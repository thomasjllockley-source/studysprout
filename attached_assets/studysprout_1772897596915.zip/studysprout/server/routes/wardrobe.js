// routes/wardrobe.js — Wardrobe shop and inventory management

import { Router } from 'express';
import db from '../database.js';

const router = Router();

// ─── Shop catalogue (static, could be DB-driven later) ─────
export const SHOP_ITEMS = [
  { name: 'party_hat',      category: 'hat',    price: 30,  emoji: '🎉', label: 'Party Hat' },
  { name: 'wizard_hat',     category: 'hat',    price: 50,  emoji: '🧙', label: 'Wizard Hat' },
  { name: 'top_hat',        category: 'hat',    price: 80,  emoji: '🎩', label: 'Top Hat' },
  { name: 'crown',          category: 'hat',    price: 150, emoji: '👑', label: 'Crown' },
  { name: 'sunglasses',     category: 'glasses',price: 40,  emoji: '😎', label: 'Sunglasses' },
  { name: 'heart_glasses',  category: 'glasses',price: 60,  emoji: '🥰', label: 'Heart Glasses' },
  { name: 'star_glasses',   category: 'glasses',price: 90,  emoji: '🌟', label: 'Star Glasses' },
  { name: 'cape',           category: 'outfit', price: 100, emoji: '🦸', label: 'Hero Cape' },
  { name: 'tuxedo',         category: 'outfit', price: 120, emoji: '🤵', label: 'Tuxedo' },
  { name: 'astronaut',      category: 'outfit', price: 200, emoji: '👨‍🚀', label: 'Astronaut Suit' },
];

// ─── GET /api/wardrobe/shop ────────────────────────────────
// Returns full catalogue + user's owned/equipped items.
router.get('/shop/:userId', (req, res) => {
  const { userId } = req.params;

  try {
    const owned = db.prepare('SELECT * FROM inventory WHERE user_id = ?').all(userId);
    const ownedMap = {};
    owned.forEach(item => { ownedMap[item.item_name] = item; });

    const catalogue = SHOP_ITEMS.map(item => ({
      ...item,
      owned:   !!ownedMap[item.name],
      equipped: ownedMap[item.name]?.equipped === 1,
    }));

    res.json({ catalogue });
  } catch (err) {
    console.error('Shop error:', err);
    res.status(500).json({ error: 'Could not load shop' });
  }
});

// ─── POST /api/wardrobe/buy ────────────────────────────────
// Deducts coins and adds item to inventory.
router.post('/buy', (req, res) => {
  const { userId, itemName } = req.body;
  if (!userId || !itemName) return res.status(400).json({ error: 'userId and itemName required' });

  const item = SHOP_ITEMS.find(i => i.name === itemName);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  try {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user.coins < item.price) return res.status(400).json({ error: 'Not enough coins!' });

    // Check already owned
    const alreadyOwned = db.prepare('SELECT * FROM inventory WHERE user_id = ? AND item_name = ?').get(userId, itemName);
    if (alreadyOwned) return res.status(400).json({ error: 'Already owned' });

    // Deduct coins and add to inventory
    db.prepare('UPDATE users SET coins = coins - ? WHERE id = ?').run(item.price, userId);
    db.prepare('INSERT INTO inventory (user_id, item_name, item_category, equipped) VALUES (?, ?, ?, 0)').run(userId, itemName, item.category);

    const updatedUser = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    res.json({ message: 'Purchased!', coins: updatedUser.coins });
  } catch (err) {
    console.error('Buy error:', err);
    res.status(500).json({ error: 'Could not complete purchase' });
  }
});

// ─── POST /api/wardrobe/equip ──────────────────────────────
// Equips an item (unequips others in same category).
router.post('/equip', (req, res) => {
  const { userId, itemName } = req.body;
  if (!userId || !itemName) return res.status(400).json({ error: 'userId and itemName required' });

  const item = SHOP_ITEMS.find(i => i.name === itemName);
  if (!item) return res.status(404).json({ error: 'Item not found' });

  try {
    // Unequip all items in same category
    db.prepare(`
      UPDATE inventory SET equipped = 0
      WHERE user_id = ? AND item_category = ?
    `).run(userId, item.category);

    // Equip the selected item
    db.prepare(`
      UPDATE inventory SET equipped = 1
      WHERE user_id = ? AND item_name = ?
    `).run(userId, itemName);

    res.json({ message: 'Equipped!' });
  } catch (err) {
    console.error('Equip error:', err);
    res.status(500).json({ error: 'Could not equip item' });
  }
});

// ─── POST /api/wardrobe/unequip ────────────────────────────
router.post('/unequip', (req, res) => {
  const { userId, itemName } = req.body;
  if (!userId || !itemName) return res.status(400).json({ error: 'userId and itemName required' });

  try {
    db.prepare('UPDATE inventory SET equipped = 0 WHERE user_id = ? AND item_name = ?').run(userId, itemName);
    res.json({ message: 'Unequipped' });
  } catch (err) {
    res.status(500).json({ error: 'Could not unequip' });
  }
});

// ─── GET /api/wardrobe/equipped/:userId ────────────────────
// Returns only the currently equipped items (for pet display).
router.get('/equipped/:userId', (req, res) => {
  const { userId } = req.params;
  try {
    const equipped = db.prepare(`
      SELECT item_name, item_category FROM inventory
      WHERE user_id = ? AND equipped = 1
    `).all(userId);
    res.json(equipped);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch equipped items' });
  }
});

export default router;
