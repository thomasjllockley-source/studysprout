# 🌱 StudySprout

> A study focus app for teenagers with virtual pets — study hard, level up your pet!

StudySprout combines the engagement loop of Duolingo with a Tamagotchi-style pet. Complete study sessions to earn XP and coins, keep your streak alive, and dress up your virtual pet!

---

## 🚀 Quick Start (Replit / Local)

```bash
# 1. Install all dependencies (root + client)
npm run install:all

# 2. Start both the backend and frontend
npm run dev
```

- **Backend** (Express API) → http://localhost:3001
- **Frontend** (Vite + React) → http://localhost:5173

> In Replit, open the Webview to http://localhost:5173

---

## 📁 Folder Structure

```
studysprout/
├── server/
│   ├── server.js           # Express entry point
│   ├── database.js         # SQLite schema + helpers
│   └── routes/
│       ├── users.js        # POST /api/user/create, GET /api/user/:id
│       ├── pets.js         # POST /api/pet/select, GET /api/pet/:userId
│       ├── sessions.js     # start / warning / complete / fail
│       ├── tests.js        # CRUD for upcoming exams
│       └── wardrobe.js     # Shop, buy, equip items
│
├── client/
│   ├── index.html
│   ├── vite.config.js      # Proxies /api → :3001
│   ├── tailwind.config.js
│   └── src/
│       ├── main.jsx        # React entry + SW registration
│       ├── App.jsx         # Router + user init
│       ├── api.js          # All fetch calls
│       ├── index.css       # Tailwind + custom styles
│       ├── components/
│       │   ├── Layout.jsx
│       │   ├── LoadingScreen.jsx
│       │   ├── PetDisplay.jsx
│       │   ├── HappinessBar.jsx
│       │   ├── XPBar.jsx
│       │   ├── StreakBadge.jsx
│       │   └── Confetti.jsx
│       └── pages/
│           ├── Home.jsx
│           ├── PetSelect.jsx
│           ├── StartSession.jsx
│           ├── Timer.jsx
│           ├── Result.jsx
│           ├── Calendar.jsx
│           └── Wardrobe.jsx
│
├── public/
│   ├── manifest.json       # PWA manifest
│   └── service-worker.js   # Offline support
│
├── database.sqlite         # Auto-created on first run
├── package.json
└── README.md
```

---

## 🎮 Feature Overview

### Anonymous User System
- On first load, a random user ID is generated and saved to `localStorage`
- No login required — the app just works

### Virtual Pets
Choose from: 🐹 Hamster · 🐶 Dog · 🐱 Cat · 🦝 Raccoon

Each pet has:
- **Happiness** (0–100): drops when sessions fail, rises on success
- **Level** (1+): increases as XP grows
- **XP**: earned by completing sessions

### Study Sessions
1. Pick a subject + duration
2. Start the timer
3. **Don't leave the tab!** — 3 warnings = session fails
4. Complete to earn: `XP = minutes × 5`, `Coins = minutes × 2`

### Streaks 🔥
Complete at least one session per day to build your streak.

### Level Progression
| Level | XP Required |
|-------|-------------|
| 1     | 0           |
| 2     | 100         |
| 3     | 250         |
| 4     | 500         |
| 5     | 900         |
| 6     | 1400        |

### Wardrobe 👗
Spend coins on hats, glasses, and outfits. Equipped items appear on your pet!

| Item          | Category | Price |
|---------------|----------|-------|
| Party Hat     | Hat      | 30    |
| Wizard Hat    | Hat      | 50    |
| Crown         | Hat      | 150   |
| Sunglasses    | Glasses  | 40    |
| Hero Cape     | Outfit   | 100   |
| Astronaut Suit| Outfit   | 200   |

### Test Calendar 📅
Log upcoming exams with subject, name, and date. The dashboard shows the next 3 tests sorted by urgency.

---

## 🔌 API Reference

| Method | Route                    | Description               |
|--------|--------------------------|---------------------------|
| POST   | /api/user/create         | Create or fetch user      |
| GET    | /api/user/:id            | Get user data             |
| POST   | /api/pet/select          | Choose starter pet        |
| GET    | /api/pet/:userId         | Get pet with XP info      |
| POST   | /api/session/start       | Start a study session     |
| POST   | /api/session/warning     | Record a tab-leave warning|
| POST   | /api/session/complete    | Complete & earn rewards   |
| POST   | /api/session/fail        | Fail, pet loses happiness |
| POST   | /api/tests/create        | Add upcoming test         |
| GET    | /api/tests/:userId       | Get all tests (sorted)    |
| DELETE | /api/tests/:id           | Remove a test             |
| GET    | /api/wardrobe/shop/:userId| Get shop catalogue       |
| POST   | /api/wardrobe/buy        | Purchase an item          |
| POST   | /api/wardrobe/equip      | Equip an item             |
| POST   | /api/wardrobe/unequip    | Remove equipped item      |
| GET    | /api/wardrobe/equipped/:userId | Get equipped items  |

---

## 🛠 Tech Stack

- **Frontend**: React 18 + Vite + TailwindCSS
- **Backend**: Node.js + Express.js
- **Database**: SQLite (via better-sqlite3)
- **PWA**: Service worker + manifest

---

## 🔧 Replit Setup Notes

1. Make sure you're using **Node.js** as the Replit template
2. In the Replit Shell, run: `npm run install:all && npm run dev`
3. The Vite dev server proxies `/api` calls to Express automatically
4. `database.sqlite` is created automatically in the project root

---

## 🎨 Design System

| Colour          | Hex       | Usage                   |
|-----------------|-----------|-------------------------|
| Sprout Green    | `#58CC02` | Primary CTA, success    |
| Dark Green      | `#3D9900` | Button shadows          |
| Yellow          | `#FFC800` | XP, coins, highlights   |
| Orange          | `#FF9600` | Streaks, warnings       |
| Blue            | `#1CB0F6` | Secondary actions       |
| Red             | `#FF4B4B` | Danger, failure         |

Font: **Nunito** (Google Fonts) — rounded, friendly, readable

---

Built with ❤️ for young learners everywhere 🌱
