// api.js — Centralised API helpers for StudySprout
// All calls go through /api (proxied to Express in dev)

const BASE = '/api';

// ── Helper: JSON POST ────────────────────────────────────────
async function post(url, body) {
  const res = await fetch(`${BASE}${url}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// ── Helper: JSON GET ─────────────────────────────────────────
async function get(url) {
  const res = await fetch(`${BASE}${url}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// ── Helper: DELETE ───────────────────────────────────────────
async function del(url) {
  const res = await fetch(`${BASE}${url}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Delete failed');
  return res.json();
}

// ─── User API ────────────────────────────────────────────────
export const createUser  = (id)       => post('/user/create', { id });
export const getUser     = (id)       => get(`/user/${id}`);

// ─── Pet API ─────────────────────────────────────────────────
export const selectPet   = (userId, petType) => post('/pet/select', { userId, petType });
export const getPet      = (userId)          => get(`/pet/${userId}`);

// ─── Session API ─────────────────────────────────────────────
export const startSession    = (userId, subject, duration) =>
  post('/session/start', { userId, subject, duration });

export const warnSession     = (sessionId) =>
  post('/session/warning', { sessionId });

export const completeSession = (sessionId, userId) =>
  post('/session/complete', { sessionId, userId });

export const failSession     = (sessionId, userId) =>
  post('/session/fail', { sessionId, userId });

// ─── Tests API ───────────────────────────────────────────────
export const createTest  = (userId, subject, name, date) =>
  post('/tests/create', { userId, subject, name, date });

export const getTests    = (userId) => get(`/tests/${userId}`);
export const deleteTest  = (id)     => del(`/tests/${id}`);

// ─── Wardrobe API ────────────────────────────────────────────
export const getShop     = (userId)            => get(`/wardrobe/shop/${userId}`);
export const buyItem     = (userId, itemName)  => post('/wardrobe/buy', { userId, itemName });
export const equipItem   = (userId, itemName)  => post('/wardrobe/equip', { userId, itemName });
export const unequipItem = (userId, itemName)  => post('/wardrobe/unequip', { userId, itemName });
export const getEquipped = (userId)            => get(`/wardrobe/equipped/${userId}`);
