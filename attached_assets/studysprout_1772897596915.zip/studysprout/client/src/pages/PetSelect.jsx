// pages/PetSelect.jsx — Onboarding: choose your starter pet

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { selectPet } from '../api.js';
import { useUser } from '../App.jsx';

const PETS = [
  { type: 'hamster', emoji: '🐹', name: 'Hamster', desc: 'Energetic and speedy!' },
  { type: 'dog',     emoji: '🐶', name: 'Dog',     desc: 'Loyal and enthusiastic!' },
  { type: 'cat',     emoji: '🐱', name: 'Cat',     desc: 'Cool and independent!' },
  { type: 'raccoon', emoji: '🦝', name: 'Raccoon',  desc: 'Curious and clever!' },
];

export default function PetSelect() {
  const { userId, setHasPet } = useUser();
  const navigate = useNavigate();

  const [selected, setSelected] = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  async function handleConfirm() {
    if (!selected) return;
    setLoading(true);
    setError('');
    try {
      await selectPet(userId, selected);
      setHasPet(true);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sprout-green to-green-400 flex flex-col items-center justify-center px-6 py-10">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="text-6xl mb-3">🌱</div>
        <h1 className="text-white font-black text-3xl">Welcome to StudySprout!</h1>
        <p className="text-green-100 font-semibold mt-2 text-lg">
          First, choose your study buddy!
        </p>
      </div>

      {/* Pet grid */}
      <div className="grid grid-cols-2 gap-4 w-full max-w-sm mb-8">
        {PETS.map(({ type, emoji, name, desc }) => {
          const isSelected = selected === type;
          return (
            <button
              key={type}
              onClick={() => setSelected(type)}
              className={`
                rounded-3xl p-5 flex flex-col items-center gap-2 transition-all duration-200
                border-4 shadow-lg
                ${isSelected
                  ? 'bg-white border-sprout-yellow scale-105 shadow-xl'
                  : 'bg-white/80 border-transparent hover:border-white hover:scale-102'
                }
              `}
            >
              <span className="text-5xl">{emoji}</span>
              <span className="font-black text-gray-800">{name}</span>
              <span className="text-gray-500 text-xs text-center">{desc}</span>
              {isSelected && (
                <span className="text-sprout-green font-bold text-sm">✓ Selected!</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-100 border border-red-300 text-red-700 rounded-xl px-4 py-2 mb-4 text-sm font-semibold">
          {error}
        </div>
      )}

      {/* Confirm button */}
      <button
        onClick={handleConfirm}
        disabled={!selected || loading}
        className={`
          w-full max-w-sm btn-primary text-xl py-4 transition-opacity
          ${(!selected || loading) ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        {loading ? 'Creating your pet…' : selected ? `Choose ${PETS.find(p => p.type === selected)?.name}! 🎉` : 'Pick a pet first!'}
      </button>
    </div>
  );
}
