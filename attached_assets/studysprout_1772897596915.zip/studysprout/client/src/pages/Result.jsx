// pages/Result.jsx — Session result: success or failure screen

import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Confetti from '../components/Confetti.jsx';

export default function Result() {
  const navigate  = useNavigate();
  const location  = useLocation();

  const { success, result = {}, subject, duration } = location.state || {};
  const [showConfetti, setShowConfetti] = useState(false);

  // Trigger confetti on success
  useEffect(() => {
    if (success) {
      setTimeout(() => setShowConfetti(true), 300);
      setTimeout(() => setShowConfetti(false), 2200);
    }
  }, [success]);

  // Redirect if navigated to directly without state
  useEffect(() => {
    if (!location.state) navigate('/');
  }, [location.state, navigate]);

  if (!location.state) return null;

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-sprout-green to-green-400 flex flex-col items-center justify-center px-6 py-10 text-center">
        <Confetti active={showConfetti} count={30} />

        {/* Trophy animation */}
        <div className="text-8xl mb-4 animate-bounce">🏆</div>

        <h1 className="text-white font-black text-3xl mb-2">
          Session Complete!
        </h1>
        <p className="text-green-100 font-semibold text-lg mb-6">
          📚 {subject} · {duration} minutes
        </p>

        {/* Rewards card */}
        <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-xl mb-6">
          <h2 className="font-black text-gray-800 text-xl mb-4">Rewards Earned 🎉</h2>

          <div className="flex justify-around mb-6">
            {/* XP */}
            <div className="flex flex-col items-center gap-1">
              <div className="w-16 h-16 bg-sprout-green/10 rounded-2xl flex items-center justify-center text-3xl">
                ⭐
              </div>
              <p className="font-black text-sprout-green text-xl">+{result.xpGained ?? duration * 5}</p>
              <p className="text-gray-400 text-xs font-bold">XP</p>
            </div>

            {/* Coins */}
            <div className="flex flex-col items-center gap-1">
              <div className="w-16 h-16 bg-sprout-yellow/20 rounded-2xl flex items-center justify-center text-3xl">
                🪙
              </div>
              <p className="font-black text-sprout-yellow text-xl">+{result.coinsGained ?? duration * 2}</p>
              <p className="text-gray-400 text-xs font-bold">Coins</p>
            </div>

            {/* Streak */}
            <div className="flex flex-col items-center gap-1">
              <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center text-3xl">
                🔥
              </div>
              <p className="font-black text-orange-500 text-xl">{result.newStreak ?? 1}</p>
              <p className="text-gray-400 text-xs font-bold">Streak</p>
            </div>
          </div>

          {/* Level up banner */}
          {result.leveledUp && (
            <div className="bg-sprout-yellow rounded-2xl px-4 py-3 mb-4 text-center">
              <p className="font-black text-gray-800 text-lg">
                🎊 Level Up! You're now Level {result.newLevel}!
              </p>
            </div>
          )}

          {/* Encouragement message */}
          <div className="bg-green-50 border-2 border-sprout-green rounded-2xl px-4 py-3">
            <p className="text-gray-700 font-semibold text-sm italic">
              "{result.message || "Great work! Your pet is so proud of you! 🐾"}"
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-3 w-full max-w-sm">
          <button
            onClick={() => navigate('/start')}
            className="btn-primary w-full text-lg py-4"
          >
            📚 Study Again
          </button>
          <button
            onClick={() => navigate('/')}
            className="bg-white text-sprout-green font-black py-4 px-6 rounded-2xl text-lg hover:bg-green-50 transition-colors"
          >
            🏠 Back to Home
          </button>
        </div>
      </div>
    );
  }

  // ── Failure screen ─────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-b from-red-400 to-red-600 flex flex-col items-center justify-center px-6 py-10 text-center">
      {/* Sad pet */}
      <div className="text-8xl mb-4 animate-bounce">😢</div>

      <h1 className="text-white font-black text-3xl mb-2">
        Session Failed!
      </h1>
      <p className="text-red-100 font-semibold text-lg mb-6">
        You left the session too many times.
      </p>

      <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-xl mb-6">
        <p className="text-4xl mb-2">💔</p>
        <p className="font-black text-gray-800 text-xl mb-2">Pet Happiness -10</p>
        <p className="text-gray-500 font-semibold text-sm">
          Your pet is feeling a little sad. Study next time to cheer them up!
        </p>

        <div className="bg-red-50 border-2 border-red-200 rounded-2xl px-4 py-3 mt-4">
          <p className="text-red-600 font-bold text-sm">
            💡 Tip: Find a quiet place and put your phone away before starting!
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-3 w-full max-w-sm">
        <button
          onClick={() => navigate('/start')}
          className="bg-white text-sprout-red font-black py-4 px-6 rounded-2xl text-lg hover:bg-red-50 transition-colors shadow-[0_4px_0_rgba(0,0,0,0.2)]"
        >
          💪 Try Again
        </button>
        <button
          onClick={() => navigate('/')}
          className="text-white font-bold py-4 px-6 rounded-2xl text-lg hover:bg-white/10 transition-colors"
        >
          🏠 Back to Home
        </button>
      </div>
    </div>
  );
}
