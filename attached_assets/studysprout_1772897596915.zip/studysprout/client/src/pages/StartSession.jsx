// pages/StartSession.jsx — Study session configuration

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../App.jsx';
import { startSession } from '../api.js';

const SUBJECTS = [
  { name: 'Maths',       emoji: '🔢' },
  { name: 'Science',     emoji: '🔬' },
  { name: 'English',     emoji: '📖' },
  { name: 'History',     emoji: '🏛️' },
  { name: 'Geography',   emoji: '🌍' },
  { name: 'Languages',   emoji: '💬' },
  { name: 'Computing',   emoji: '💻' },
  { name: 'Art',         emoji: '🎨' },
  { name: 'Music',       emoji: '🎵' },
  { name: 'Other',       emoji: '📝' },
];

const DURATIONS = [
  { mins: 10,  label: '10 min',  desc: 'Quick burst' },
  { mins: 15,  label: '15 min',  desc: 'Short session' },
  { mins: 25,  label: '25 min',  desc: 'Pomodoro ⭐', featured: true },
  { mins: 30,  label: '30 min',  desc: 'Half hour' },
  { mins: 45,  label: '45 min',  desc: 'Deep work' },
  { mins: 60,  label: '60 min',  desc: 'Power hour' },
];

export default function StartSession() {
  const { userId } = useUser();
  const navigate   = useNavigate();

  const [subject,  setSubject]  = useState('');
  const [duration, setDuration] = useState(25); // default: Pomodoro
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  async function handleStart() {
    if (!subject) { setError('Please pick a subject!'); return; }
    setLoading(true);
    setError('');
    try {
      const { sessionId } = await startSession(userId, subject, duration);
      // Pass session config to timer via navigation state
      navigate('/timer', { state: { sessionId, subject, duration } });
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <div className="px-4 pt-6 pb-4 flex flex-col gap-5">
      {/* Header */}
      <div>
        <h1 className="font-black text-2xl text-gray-800">📚 New Session</h1>
        <p className="text-gray-500 font-semibold">
          What are you studying today?
        </p>
      </div>

      {/* Subject picker */}
      <div className="card">
        <h2 className="font-black text-gray-700 mb-3">Choose Subject</h2>
        <div className="grid grid-cols-2 gap-2">
          {SUBJECTS.map(({ name, emoji }) => (
            <button
              key={name}
              onClick={() => { setSubject(name); setError(''); }}
              className={`
                flex items-center gap-2 rounded-2xl px-4 py-3 font-bold text-sm transition-all
                border-2
                ${subject === name
                  ? 'bg-sprout-green text-white border-sprout-dark scale-105'
                  : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-sprout-green hover:bg-green-50'
                }
              `}
            >
              <span className="text-xl">{emoji}</span>
              {name}
            </button>
          ))}
        </div>
      </div>

      {/* Duration picker */}
      <div className="card">
        <h2 className="font-black text-gray-700 mb-3">Session Length</h2>
        <div className="grid grid-cols-3 gap-2">
          {DURATIONS.map(({ mins, label, desc, featured }) => (
            <button
              key={mins}
              onClick={() => setDuration(mins)}
              className={`
                flex flex-col items-center rounded-2xl py-3 px-2 font-bold transition-all border-2 relative
                ${duration === mins
                  ? 'bg-sprout-blue text-white border-blue-400 scale-105'
                  : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-sprout-blue hover:bg-blue-50'
                }
              `}
            >
              {featured && (
                <span className="absolute -top-2 -right-2 bg-sprout-yellow text-gray-800 text-xs font-black rounded-full px-1.5 py-0.5">
                  Best
                </span>
              )}
              <span className="text-lg font-black">{label}</span>
              <span className={`text-xs mt-0.5 ${duration === mins ? 'text-blue-100' : 'text-gray-400'}`}>
                {desc}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Tips card */}
      <div className="bg-sprout-yellow/20 border-2 border-sprout-yellow rounded-3xl p-4">
        <p className="font-black text-gray-700 text-sm">💡 Tip</p>
        <p className="text-gray-600 text-sm mt-1">
          Put your phone down, close distractions, and commit fully.
          Your pet is counting on you! 🐾
        </p>
        <p className="text-sprout-green font-black text-sm mt-2">
          Reward: +{duration * 5} XP & +{duration * 2} coins 🪙
        </p>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-100 border border-red-300 text-red-700 rounded-xl px-4 py-2 text-sm font-semibold">
          {error}
        </div>
      )}

      {/* Start button */}
      <button
        onClick={handleStart}
        disabled={loading}
        className="btn-primary w-full text-xl py-5 disabled:opacity-50"
      >
        {loading ? 'Starting…' : `🚀 Start ${duration}-minute session!`}
      </button>
    </div>
  );
}
