// pages/Timer.jsx — Countdown timer with focus detection

import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useUser } from '../App.jsx';
import { warnSession, completeSession, failSession } from '../api.js';

// Encouraging messages shown during the session
const CHEER_MESSAGES = [
  'Keep going! You\'re doing amazing! 💪',
  'Stay focused! Your pet is cheering for you! 🐾',
  'You\'ve got this! Every minute counts! ⭐',
  'Incredible focus! Keep it up! 🌟',
  'Your dedication is inspiring! 📚',
  'Almost there! Don\'t give up! 🏆',
];

function formatTime(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = (seconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function Timer() {
  const navigate   = useNavigate();
  const location   = useLocation();
  const { userId } = useUser();

  // Extract session details passed from StartSession
  const { sessionId, subject, duration } = location.state || {};

  const totalSeconds    = (duration || 25) * 60;
  const [timeLeft,  setTimeLeft]  = useState(totalSeconds);
  const [paused,    setPaused]    = useState(false);
  const [warnings,  setWarnings]  = useState(0);
  const [cheerIdx,  setCheerIdx]  = useState(0);
  const [showWarnBanner, setShowWarnBanner] = useState(false);
  const [finished,  setFinished]  = useState(false);

  const timerRef    = useRef(null);
  const cheerRef    = useRef(null);
  const warnCount   = useRef(0);

  // ── Redirect if no session data ──────────────────────────
  useEffect(() => {
    if (!sessionId) navigate('/start');
  }, [sessionId, navigate]);

  // ── Main countdown tick ──────────────────────────────────
  useEffect(() => {
    if (paused || finished) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          handleComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [paused, finished]);

  // ── Rotate cheer messages every 30 seconds ───────────────
  useEffect(() => {
    cheerRef.current = setInterval(() => {
      setCheerIdx((i) => (i + 1) % CHEER_MESSAGES.length);
    }, 30000);
    return () => clearInterval(cheerRef.current);
  }, []);

  // ── Tab/window visibility detection ─────────────────────
  useEffect(() => {
    const handleVisibility = async () => {
      if (document.hidden && !finished) {
        warnCount.current += 1;
        const newCount = warnCount.current;
        setWarnings(newCount);
        setShowWarnBanner(true);

        try { await warnSession(sessionId); } catch (_) {}

        setTimeout(() => setShowWarnBanner(false), 4000);

        if (newCount >= 3) {
          handleFail();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [sessionId, finished]);

  // ── Complete session ─────────────────────────────────────
  const handleComplete = useCallback(async () => {
    if (finished) return;
    setFinished(true);
    clearInterval(timerRef.current);
    try {
      const result = await completeSession(sessionId, userId);
      navigate('/result', { state: { success: true, result, subject, duration } });
    } catch (err) {
      console.error('Complete error:', err);
      navigate('/result', { state: { success: true, result: {}, subject, duration } });
    }
  }, [finished, sessionId, userId, navigate, subject, duration]);

  // ── Fail session ─────────────────────────────────────────
  const handleFail = useCallback(async () => {
    if (finished) return;
    setFinished(true);
    clearInterval(timerRef.current);
    try {
      const result = await failSession(sessionId, userId);
      navigate('/result', { state: { success: false, result, subject, duration } });
    } catch (err) {
      navigate('/result', { state: { success: false, result: {}, subject, duration } });
    }
  }, [finished, sessionId, userId, navigate, subject, duration]);

  // ── Progress percentage ──────────────────────────────────
  const progress    = ((totalSeconds - timeLeft) / totalSeconds) * 100;
  const circumference = 2 * Math.PI * 90; // radius=90
  const strokeDash  = circumference - (progress / 100) * circumference;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-sprout-blue/10 to-white">

      {/* ── Warning banner ── */}
      {showWarnBanner && (
        <div
          className={`fixed top-0 left-0 right-0 z-50 px-4 py-3 text-center font-black text-white text-sm animate-pop ${
            warnings >= 3 ? 'bg-sprout-red' : 'bg-sprout-orange'
          }`}
        >
          {warnings >= 3
            ? '❌ 3 warnings! Session failed! Your pet is sad 😢'
            : `⚠️ Warning ${warnings}/3 — Stay on the page!`
          }
        </div>
      )}

      {/* ── Header ── */}
      <div className="px-4 pt-12 pb-4 flex items-center justify-between">
        <div>
          <h1 className="font-black text-xl text-gray-800">Study Session</h1>
          <p className="text-gray-500 font-semibold text-sm">📚 {subject}</p>
        </div>
        {/* Warning dots */}
        <div className="flex gap-1">
          {[1, 2, 3].map((n) => (
            <span
              key={n}
              className={`w-3 h-3 rounded-full ${
                warnings >= n ? 'bg-sprout-red' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* ── Circular timer ── */}
      <div className="flex-1 flex flex-col items-center justify-center gap-6 px-4">
        <div className="relative">
          <svg width="220" height="220" viewBox="0 0 220 220">
            {/* Background track */}
            <circle
              cx="110" cy="110" r="90"
              fill="none" stroke="#E5E7EB" strokeWidth="12"
            />
            {/* Progress arc */}
            <circle
              cx="110" cy="110" r="90"
              fill="none"
              stroke={paused ? '#FFC800' : '#58CC02'}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDash}
              transform="rotate(-90 110 110)"
              style={{ transition: 'stroke-dashoffset 1s linear' }}
            />
          </svg>

          {/* Time display in centre */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-black text-5xl text-gray-800 tracking-tight">
              {formatTime(timeLeft)}
            </span>
            <span className="text-gray-400 font-semibold text-sm mt-1">
              {paused ? '⏸ Paused' : 'remaining'}
            </span>
          </div>
        </div>

        {/* Cheer message */}
        <div className="card text-center px-6 py-4 mx-4 w-full max-w-xs">
          <p className="font-bold text-gray-700">{CHEER_MESSAGES[cheerIdx]}</p>
        </div>

        {/* Controls */}
        <div className="flex gap-4 w-full max-w-xs">
          <button
            onClick={() => setPaused((p) => !p)}
            className="btn-secondary flex-1 text-lg"
          >
            {paused ? '▶ Resume' : '⏸ Pause'}
          </button>
          <button
            onClick={() => {
              if (confirm('Give up? Your pet will be sad 😢')) handleFail();
            }}
            className="btn-danger flex-1 text-lg"
          >
            🏳 Give up
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full max-w-xs">
          <div className="flex justify-between text-xs font-bold text-gray-400 mb-1">
            <span>0 min</span>
            <span>{duration} min</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="h-full xp-bar-fill rounded-full transition-all duration-1000"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-center text-xs text-gray-500 font-semibold mt-1">
            {Math.round(progress)}% complete
          </p>
        </div>

        {/* Don't leave warning */}
        <div className="bg-orange-50 border-2 border-orange-200 rounded-2xl px-4 py-3 w-full max-w-xs text-center">
          <p className="text-orange-600 font-bold text-xs">
            ⚠️ Stay on this page! Leaving 3 times will fail the session.
          </p>
        </div>
      </div>
    </div>
  );
}
