// pages/Calendar.jsx — Manage upcoming tests/exams

import { useState, useEffect } from 'react';
import { useUser } from '../App.jsx';
import { createTest, getTests, deleteTest } from '../api.js';

const SUBJECTS = ['Maths', 'Science', 'English', 'History', 'Geography',
                  'Languages', 'Computing', 'Art', 'Music', 'Other'];

// Format date for display
function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

// Days until test
function daysUntil(dateStr) {
  const now    = new Date(); now.setHours(0,0,0,0);
  const target = new Date(dateStr + 'T00:00:00');
  const diff   = Math.round((target - now) / 86400000);
  if (diff < 0)  return { label: 'Past',      colour: 'text-gray-400' };
  if (diff === 0) return { label: 'TODAY! 🔥', colour: 'text-red-600' };
  if (diff === 1) return { label: 'Tomorrow',  colour: 'text-orange-500' };
  if (diff <= 7)  return { label: `${diff} days`, colour: 'text-orange-400' };
  return { label: `${diff} days`, colour: 'text-gray-500' };
}

export default function Calendar() {
  const { userId } = useUser();

  const [tests,   setTests]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  // Form state
  const [formSubject, setFormSubject] = useState(SUBJECTS[0]);
  const [formName,    setFormName]    = useState('');
  const [formDate,    setFormDate]    = useState('');
  const [saving,      setSaving]      = useState(false);
  const [error,       setError]       = useState('');

  // Load tests
  async function load() {
    try {
      const data = await getTests(userId);
      setTests(data);
    } catch (err) {
      console.error('Load tests error:', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [userId]);

  // Add test
  async function handleAdd() {
    if (!formName.trim()) { setError('Please enter a test name'); return; }
    if (!formDate)        { setError('Please pick a date'); return; }

    setSaving(true);
    setError('');
    try {
      await createTest(userId, formSubject, formName.trim(), formDate);
      setFormName('');
      setFormDate('');
      setShowForm(false);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  // Delete test
  async function handleDelete(id) {
    if (!confirm('Remove this test?')) return;
    try {
      await deleteTest(id);
      setTests((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      alert('Could not delete: ' + err.message);
    }
  }

  // Min date = today
  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="px-4 pt-6 pb-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-black text-2xl text-gray-800">📅 Test Calendar</h1>
          <p className="text-gray-500 font-semibold text-sm">Track your upcoming exams</p>
        </div>
        <button
          onClick={() => { setShowForm(!showForm); setError(''); }}
          className={`font-black text-sm px-4 py-2 rounded-2xl transition-all ${
            showForm ? 'bg-gray-200 text-gray-700' : 'bg-sprout-green text-white shadow-[0_3px_0_#3D9900]'
          }`}
        >
          {showForm ? '✕ Cancel' : '+ Add Test'}
        </button>
      </div>

      {/* Add test form */}
      {showForm && (
        <div className="card border-2 border-sprout-green animate-pop">
          <h2 className="font-black text-gray-800 mb-4">📝 New Test</h2>

          {/* Subject */}
          <label className="block mb-3">
            <span className="text-xs font-black text-gray-500 uppercase tracking-wide mb-1 block">Subject</span>
            <select
              value={formSubject}
              onChange={(e) => setFormSubject(e.target.value)}
              className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 font-bold text-gray-800 focus:border-sprout-green focus:outline-none"
            >
              {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>

          {/* Test name */}
          <label className="block mb-3">
            <span className="text-xs font-black text-gray-500 uppercase tracking-wide mb-1 block">Test Name</span>
            <input
              type="text"
              placeholder="e.g. End of Year Maths Exam"
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 font-semibold text-gray-800 focus:border-sprout-green focus:outline-none"
            />
          </label>

          {/* Date */}
          <label className="block mb-4">
            <span className="text-xs font-black text-gray-500 uppercase tracking-wide mb-1 block">Date</span>
            <input
              type="date"
              min={todayStr}
              value={formDate}
              onChange={(e) => setFormDate(e.target.value)}
              className="w-full border-2 border-gray-200 rounded-2xl px-4 py-3 font-semibold text-gray-800 focus:border-sprout-green focus:outline-none"
            />
          </label>

          {error && (
            <p className="text-sprout-red font-bold text-sm mb-3">{error}</p>
          )}

          <button
            onClick={handleAdd}
            disabled={saving}
            className="btn-primary w-full disabled:opacity-50"
          >
            {saving ? 'Saving…' : '✅ Add Test'}
          </button>
        </div>
      )}

      {/* Tests list */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <span className="text-4xl animate-bounce">📅</span>
        </div>
      ) : tests.length === 0 ? (
        <div className="card flex flex-col items-center py-10 gap-3">
          <span className="text-5xl">📭</span>
          <p className="font-black text-gray-700 text-lg">No tests logged yet!</p>
          <p className="text-gray-400 font-semibold text-sm text-center">
            Add your upcoming tests to stay on top of revision
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary mt-2"
          >
            + Add your first test
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tests.map((test) => {
            const { label, colour } = daysUntil(test.date);
            return (
              <div key={test.id} className="card flex items-center gap-4">
                {/* Colour dot */}
                <div className={`w-3 h-3 rounded-full flex-shrink-0 ${
                  label.includes('TODAY') ? 'bg-sprout-red' :
                  label === 'Tomorrow'    ? 'bg-sprout-orange' :
                  'bg-sprout-blue'
                }`} />

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="font-black text-gray-800 truncate">{test.name}</p>
                  <p className="text-gray-500 text-xs font-semibold">{test.subject}</p>
                  <p className="text-gray-400 text-xs">{formatDate(test.date)}</p>
                </div>

                {/* Days until */}
                <div className="text-right flex-shrink-0">
                  <p className={`font-black text-sm ${colour}`}>{label}</p>
                </div>

                {/* Delete */}
                <button
                  onClick={() => handleDelete(test.id)}
                  className="text-gray-300 hover:text-sprout-red transition-colors text-xl flex-shrink-0"
                  title="Delete test"
                >
                  ✕
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Motivational footer */}
      {tests.length > 0 && (
        <div className="bg-sprout-blue/10 border-2 border-sprout-blue/30 rounded-3xl p-4 text-center">
          <p className="font-bold text-gray-700 text-sm">
            📚 You have <span className="text-sprout-blue font-black">{tests.length}</span> upcoming test{tests.length !== 1 ? 's' : ''}. Stay on top of revision! 💪
          </p>
        </div>
      )}
    </div>
  );
}
