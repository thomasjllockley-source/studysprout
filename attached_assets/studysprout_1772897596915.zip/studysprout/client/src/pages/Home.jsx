// pages/Home.jsx — Main dashboard: pet, stats, streak, tests

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../App.jsx';
import { getUser, getPet, getTests, getEquipped } from '../api.js';

import PetDisplay   from '../components/PetDisplay.jsx';
import HappinessBar from '../components/HappinessBar.jsx';
import XPBar        from '../components/XPBar.jsx';
import StreakBadge  from '../components/StreakBadge.jsx';

// Daily missions — randomly selected on load
const MISSIONS = [
  { task: 'Complete a 25-min study session',   xp: 125,  icon: '📚' },
  { task: 'Study Maths for 15 minutes',        xp: 75,   icon: '🔢' },
  { task: 'Do a 30-minute revision session',   xp: 150,  icon: '✏️' },
  { task: 'Study Science for 20 minutes',      xp: 100,  icon: '🔬' },
  { task: 'Complete 2 study sessions today',   xp: 200,  icon: '🏆' },
];

function getDailyMission() {
  // Deterministic per day so it doesn't change on re-render
  const dayIndex = Math.floor(Date.now() / 86400000) % MISSIONS.length;
  return MISSIONS[dayIndex];
}

// Format a date string nicely
function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
}

// Days until a future date
function daysUntil(dateStr) {
  const now = new Date();
  const target = new Date(dateStr);
  const diff = Math.ceil((target - now) / 86400000);
  if (diff < 0) return 'Past';
  if (diff === 0) return 'Today!';
  if (diff === 1) return 'Tomorrow';
  return `${diff} days`;
}

export default function Home() {
  const { userId } = useUser();
  const navigate   = useNavigate();

  const [user,     setUser]     = useState(null);
  const [pet,      setPet]      = useState(null);
  const [tests,    setTests]    = useState([]);
  const [equipped, setEquipped] = useState([]);
  const [loading,  setLoading]  = useState(true);

  const mission = getDailyMission();

  useEffect(() => {
    async function load() {
      try {
        const [u, p, t, eq] = await Promise.all([
          getUser(userId),
          getPet(userId),
          getTests(userId),
          getEquipped(userId),
        ]);
        setUser(u);
        setPet(p);
        setTests(t.slice(0, 3)); // show next 3 only
        setEquipped(eq);
      } catch (err) {
        console.error('Home load error:', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [userId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <span className="text-4xl animate-bounce">🌱</span>
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 pb-4 flex flex-col gap-4">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-black text-2xl text-gray-800">StudySprout 🌱</h1>
          <p className="text-gray-500 font-semibold text-sm">
            {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
          </p>
        </div>
        {/* Coin display */}
        <div className="flex items-center gap-1.5 bg-sprout-yellow/20 border-2 border-sprout-yellow rounded-2xl px-3 py-1.5">
          <span className="text-xl">🪙</span>
          <span className="font-black text-gray-800 text-lg">{user?.coins ?? 0}</span>
        </div>
      </div>

      {/* ── Pet card ── */}
      <div className="card flex flex-col items-center gap-4 pt-6">
        <PetDisplay
          petType={pet?.pet_type}
          happiness={pet?.happiness}
          level={pet?.level}
          equipped={equipped}
          size="lg"
          animate
        />

        <div className="w-full flex flex-col gap-3 mt-2">
          <HappinessBar happiness={pet?.happiness ?? 80} />
          <XPBar
            xp={pet?.xp}
            xpProgress={pet?.xpProgress}
            xpNeeded={pet?.xpNeeded}
            level={pet?.level}
          />
        </div>
      </div>

      {/* ── Streak ── */}
      <div className="card flex items-center justify-between">
        <StreakBadge streak={user?.streak ?? 0} />
        <div className="text-right">
          <p className="text-gray-400 text-xs font-bold">TOTAL SESSIONS</p>
          <p className="text-gray-700 font-black text-2xl">
            {/* Could query this — placeholder for now */}
            📖
          </p>
        </div>
      </div>

      {/* ── Daily Mission ── */}
      <div className="card border-2 border-sprout-green bg-green-50">
        <div className="flex items-start gap-3">
          <span className="text-3xl">{mission.icon}</span>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-xs font-black text-sprout-green uppercase tracking-wider">
                Daily Mission
              </span>
            </div>
            <p className="font-bold text-gray-800">{mission.task}</p>
            <p className="text-sprout-green font-black text-sm mt-1">+{mission.xp} XP reward</p>
          </div>
        </div>
      </div>

      {/* ── Start Study Button ── */}
      <button
        className="btn-primary w-full text-xl py-5"
        onClick={() => navigate('/start')}
      >
        📚 Start Studying!
      </button>

      {/* ── Upcoming Tests ── */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-black text-gray-800 text-lg">📅 Upcoming Tests</h2>
          <button
            onClick={() => navigate('/calendar')}
            className="text-sprout-blue font-bold text-sm hover:underline"
          >
            View all
          </button>
        </div>

        {tests.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-gray-400 font-semibold">No upcoming tests</p>
            <button
              onClick={() => navigate('/calendar')}
              className="text-sprout-blue font-bold text-sm mt-1 hover:underline"
            >
              + Add a test
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {tests.map((test) => {
              const urgency = daysUntil(test.date);
              const isUrgent = urgency === 'Today!' || urgency === 'Tomorrow';
              return (
                <div
                  key={test.id}
                  className={`flex items-center justify-between rounded-2xl px-4 py-3 ${
                    isUrgent ? 'bg-red-50 border-2 border-red-200' : 'bg-gray-50'
                  }`}
                >
                  <div>
                    <p className="font-bold text-gray-800 text-sm">{test.name}</p>
                    <p className="text-gray-500 text-xs">{test.subject}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-black text-sm ${isUrgent ? 'text-sprout-red' : 'text-gray-600'}`}>
                      {urgency}
                    </p>
                    <p className="text-gray-400 text-xs">{formatDate(test.date)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom padding */}
      <div className="h-2" />
    </div>
  );
}
