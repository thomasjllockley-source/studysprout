// pages/Wardrobe.jsx — Wardrobe shop: buy and equip items for your pet

import { useState, useEffect } from 'react';
import { useUser } from '../App.jsx';
import { getShop, buyItem, equipItem, unequipItem, getUser } from '../api.js';

const CATEGORIES = ['all', 'hat', 'glasses', 'outfit'];

const CATEGORY_LABELS = {
  all:     '✨ All',
  hat:     '🎩 Hats',
  glasses: '😎 Glasses',
  outfit:  '👗 Outfits',
};

export default function Wardrobe() {
  const { userId } = useUser();

  const [catalogue,  setCatalogue]  = useState([]);
  const [coins,      setCoins]      = useState(0);
  const [filter,     setFilter]     = useState('all');
  const [loading,    setLoading]    = useState(true);
  const [actionItem, setActionItem] = useState(null); // which item is being acted on
  const [toast,      setToast]      = useState('');

  async function load() {
    try {
      const [shop, user] = await Promise.all([getShop(userId), getUser(userId)]);
      setCatalogue(shop.catalogue);
      setCoins(user.coins);
    } catch (err) {
      console.error('Wardrobe load error:', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [userId]);

  // Show a brief toast notification
  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  }

  // Buy an item
  async function handleBuy(item) {
    if (coins < item.price) { showToast('Not enough coins! 😅'); return; }
    setActionItem(item.name);
    try {
      const { coins: newCoins } = await buyItem(userId, item.name);
      setCoins(newCoins);
      showToast(`${item.emoji} ${item.label} purchased!`);
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setActionItem(null);
    }
  }

  // Equip / unequip an item
  async function handleEquip(item) {
    setActionItem(item.name);
    try {
      if (item.equipped) {
        await unequipItem(userId, item.name);
        showToast('Item removed 👗');
      } else {
        await equipItem(userId, item.name);
        showToast(`${item.emoji} Equipped!`);
      }
      await load();
    } catch (err) {
      showToast(err.message);
    } finally {
      setActionItem(null);
    }
  }

  // Filter items
  const visible = filter === 'all'
    ? catalogue
    : catalogue.filter((i) => i.category === filter);

  return (
    <div className="px-4 pt-6 pb-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-black text-2xl text-gray-800">👗 Wardrobe</h1>
          <p className="text-gray-500 font-semibold text-sm">Dress up your pet!</p>
        </div>
        {/* Coin balance */}
        <div className="flex items-center gap-1.5 bg-sprout-yellow/20 border-2 border-sprout-yellow rounded-2xl px-3 py-1.5">
          <span className="text-xl">🪙</span>
          <span className="font-black text-gray-800 text-lg">{coins}</span>
        </div>
      </div>

      {/* Toast notification */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-gray-800 text-white font-bold text-sm rounded-2xl px-5 py-3 shadow-xl animate-pop">
          {toast}
        </div>
      )}

      {/* Category filter tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`flex-shrink-0 font-bold text-sm px-4 py-2 rounded-2xl transition-all ${
              filter === cat
                ? 'bg-sprout-green text-white shadow-[0_2px_0_#3D9900]'
                : 'bg-white text-gray-600 border-2 border-gray-200 hover:border-sprout-green'
            }`}
          >
            {CATEGORY_LABELS[cat]}
          </button>
        ))}
      </div>

      {/* How to earn coins tip */}
      <div className="bg-sprout-yellow/20 border-2 border-sprout-yellow rounded-2xl px-4 py-3 text-sm">
        <span className="font-black text-gray-700">💡 </span>
        <span className="text-gray-600 font-semibold">Earn coins by completing study sessions! Each minute = 2 coins 🪙</span>
      </div>

      {/* Item grid */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <span className="text-4xl animate-bounce">👗</span>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {visible.map((item) => {
            const canAfford = coins >= item.price;
            const isActing  = actionItem === item.name;

            return (
              <div
                key={item.name}
                className={`
                  card flex flex-col items-center gap-2 py-5 relative transition-all
                  ${item.equipped ? 'border-2 border-sprout-green bg-green-50' : ''}
                  ${item.owned && !item.equipped ? 'border-2 border-sprout-blue/30' : ''}
                `}
              >
                {/* Equipped badge */}
                {item.equipped && (
                  <span className="absolute top-2 right-2 bg-sprout-green text-white text-xs font-black rounded-full px-2 py-0.5">
                    On ✓
                  </span>
                )}

                {/* Item emoji */}
                <span className="text-5xl">{item.emoji}</span>
                <p className="font-black text-gray-800 text-center text-sm">{item.label}</p>
                <p className="text-gray-400 text-xs capitalize">{item.category}</p>

                {/* Price / action button */}
                {!item.owned ? (
                  // Buy button
                  <button
                    onClick={() => handleBuy(item)}
                    disabled={isActing || !canAfford}
                    className={`
                      w-full rounded-2xl py-2 font-black text-sm transition-all mt-1
                      ${canAfford
                        ? 'bg-sprout-yellow text-gray-800 shadow-[0_3px_0_#CC9900] hover:opacity-90 active:translate-y-0.5 active:shadow-none'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      }
                    `}
                  >
                    {isActing ? '…' : `🪙 ${item.price}`}
                  </button>
                ) : (
                  // Equip/unequip button
                  <button
                    onClick={() => handleEquip(item)}
                    disabled={isActing}
                    className={`
                      w-full rounded-2xl py-2 font-black text-sm transition-all mt-1
                      ${item.equipped
                        ? 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                        : 'bg-sprout-blue text-white shadow-[0_3px_0_#0E8ACA] hover:opacity-90 active:translate-y-0.5 active:shadow-none'
                      }
                    `}
                  >
                    {isActing ? '…' : item.equipped ? 'Remove' : 'Equip'}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      <div className="h-2" />
    </div>
  );
}
