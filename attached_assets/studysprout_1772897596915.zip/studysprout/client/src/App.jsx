// App.jsx — Root component: handles routing and user initialisation

import { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

import { createUser, getPet } from './api.js';
import Layout          from './components/Layout.jsx';
import Home            from './pages/Home.jsx';
import StartSession    from './pages/StartSession.jsx';
import Timer           from './pages/Timer.jsx';
import Result          from './pages/Result.jsx';
import Wardrobe        from './pages/Wardrobe.jsx';
import Calendar        from './pages/Calendar.jsx';
import PetSelect       from './pages/PetSelect.jsx';
import LoadingScreen   from './components/LoadingScreen.jsx';

// ── Global user context ─────────────────────────────────────
export const UserContext = createContext(null);
export const useUser = () => useContext(UserContext);

// Generate a random user ID (v4-style UUID)
function generateUserId() {
  return 'user_' + Math.random().toString(36).slice(2, 11) + Date.now().toString(36);
}

export default function App() {
  const [userId, setUserId]   = useState(null);
  const [hasPet, setHasPet]   = useState(false);
  const [loading, setLoading] = useState(true);
  const [user, setUser]       = useState(null);

  // ── On first load: get or create user ID ─────────────────
  useEffect(() => {
    async function init() {
      try {
        let id = localStorage.getItem('studysprout_user_id');

        if (!id) {
          id = generateUserId();
          localStorage.setItem('studysprout_user_id', id);
        }

        // Register user in the database (idempotent)
        const userData = await createUser(id);
        setUser(userData);
        setUserId(id);

        // Check if user already has a pet
        const pet = await getPet(id).catch(() => null);
        setHasPet(!!pet);
      } catch (err) {
        console.error('Init error:', err);
      } finally {
        setLoading(false);
      }
    }

    init();
  }, []);

  if (loading) return <LoadingScreen />;

  return (
    <UserContext.Provider value={{ userId, user, setUser, hasPet, setHasPet }}>
      <BrowserRouter>
        <Routes>
          {/* Pet selection gate — shown only if no pet yet */}
          <Route
            path="/select-pet"
            element={hasPet ? <Navigate to="/" /> : <PetSelect />}
          />

          {/* Main app — redirect to pet select if no pet */}
          <Route element={<Layout />}>
            <Route
              path="/"
              element={hasPet ? <Home /> : <Navigate to="/select-pet" />}
            />
            <Route
              path="/start"
              element={hasPet ? <StartSession /> : <Navigate to="/select-pet" />}
            />
            <Route
              path="/timer"
              element={hasPet ? <Timer /> : <Navigate to="/select-pet" />}
            />
            <Route
              path="/result"
              element={hasPet ? <Result /> : <Navigate to="/select-pet" />}
            />
            <Route
              path="/wardrobe"
              element={hasPet ? <Wardrobe /> : <Navigate to="/select-pet" />}
            />
            <Route
              path="/calendar"
              element={hasPet ? <Calendar /> : <Navigate to="/select-pet" />}
            />
          </Route>

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </UserContext.Provider>
  );
}
