// XPBar.jsx — Shows XP progress toward next level

export default function XPBar({ xp = 0, xpProgress = 0, xpNeeded = 100, level = 1 }) {
  const pct = xpNeeded > 0 ? Math.min(100, (xpProgress / xpNeeded) * 100) : 100;

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">XP</span>
        <span className="text-xs font-bold text-gray-700">
          {xpProgress} / {xpNeeded} → Lv.{level + 1}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
        <div
          className="h-full rounded-full xp-bar-fill transition-all duration-1000"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
