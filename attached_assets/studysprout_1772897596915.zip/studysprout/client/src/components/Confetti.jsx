// Confetti.jsx — Simple CSS confetti burst for celebration moments

import { useEffect, useState } from 'react';

const COLOURS = ['#58CC02', '#FFC800', '#FF9600', '#1CB0F6', '#CE82FF', '#FF4B4B'];
const EMOJIS  = ['⭐', '🌟', '✨', '🎉', '🎊', '💫'];

function randomBetween(a, b) {
  return a + Math.random() * (b - a);
}

export default function Confetti({ active = false, count = 20 }) {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    if (!active) { setParticles([]); return; }

    const newParticles = Array.from({ length: count }, (_, i) => ({
      id: i,
      x: randomBetween(10, 90),        // % from left
      delay: randomBetween(0, 0.6),    // stagger
      emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
      colour: COLOURS[Math.floor(Math.random() * COLOURS.length)],
      size: randomBetween(14, 22),
    }));
    setParticles(newParticles);

    // Auto-clear after animation
    const timer = setTimeout(() => setParticles([]), 1800);
    return () => clearTimeout(timer);
  }, [active, count]);

  if (!particles.length) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute confetti-dot select-none"
          style={{
            left: `${p.x}%`,
            top: '10%',
            fontSize: `${p.size}px`,
            animationDelay: `${p.delay}s`,
            animationDuration: '1.2s',
          }}
        >
          {p.emoji}
        </span>
      ))}
    </div>
  );
}
