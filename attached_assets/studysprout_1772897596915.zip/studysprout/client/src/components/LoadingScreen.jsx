// LoadingScreen.jsx — Shown while the app initialises
export default function LoadingScreen() {
  return (
    <div className="min-h-screen bg-sprout-green flex flex-col items-center justify-center gap-6">
      {/* Animated logo */}
      <div className="text-7xl animate-bounce">🌱</div>
      <h1 className="text-white font-black text-4xl tracking-tight">StudySprout</h1>
      <p className="text-green-100 font-semibold text-lg">Getting your garden ready…</p>

      {/* Loading dots */}
      <div className="flex gap-2 mt-4">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="w-3 h-3 bg-white rounded-full animate-bounce"
            style={{ animationDelay: `${i * 0.15}s` }}
          />
        ))}
      </div>
    </div>
  );
}
