// HappinessBar.jsx — Displays pet happiness as a coloured progress bar

export default function HappinessBar({ happiness = 80 }) {
  // Colour changes based on happiness level
  const getColour = () => {
    if (happiness >= 70) return 'bg-sprout-green';
    if (happiness >= 40) return 'bg-sprout-yellow';
    return 'bg-sprout-red';
  };

  const getLabel = () => {
    if (happiness >= 80) return '😊 Happy';
    if (happiness >= 60) return '🙂 Good';
    if (happiness >= 40) return '😐 Okay';
    if (happiness >= 20) return '😟 Sad';
    return '😢 Very sad';
  };

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Happiness</span>
        <span className="text-xs font-bold text-gray-700">{getLabel()}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${getColour()}`}
          style={{ width: `${happiness}%` }}
        />
      </div>
    </div>
  );
}
