// PetDisplay.jsx — Renders an animated SVG pet with optional wardrobe items

// Pet emoji representations (used in the SVG "face")
const PET_DATA = {
  hamster: { body: '#F4A460', face: '🐹', bg: '#FFF3E0' },
  dog:     { body: '#D2691E', face: '🐶', bg: '#FFF8E1' },
  cat:     { body: '#808080', face: '🐱', bg: '#F3E5F5' },
  raccoon: { body: '#555555', face: '🦝', bg: '#E8F5E9' },
};

// Maps wardrobe item names to display emoji
const ITEM_EMOJI = {
  party_hat:    '🎉', wizard_hat: '🧙', top_hat: '🎩', crown: '👑',
  sunglasses:   '😎', heart_glasses: '🥰', star_glasses: '🌟',
  cape:         '🦸', tuxedo: '🤵', astronaut: '👨‍🚀',
};

/**
 * PetDisplay
 * @param {string} petType - 'hamster' | 'dog' | 'cat' | 'raccoon'
 * @param {number} happiness - 0-100
 * @param {number} level - 1+
 * @param {Array}  equipped - [{ item_name, item_category }]
 * @param {string} size - 'sm' | 'md' | 'lg'
 * @param {boolean} animate - whether to float
 */
export default function PetDisplay({
  petType = 'hamster',
  happiness = 80,
  level = 1,
  equipped = [],
  size = 'md',
  animate = true,
}) {
  const pet = PET_DATA[petType] || PET_DATA.hamster;

  // Choose expression based on happiness
  const getMood = () => {
    if (happiness >= 80) return '😊';
    if (happiness >= 50) return '😐';
    if (happiness >= 25) return '😟';
    return '😢';
  };

  const sizeMap = {
    sm: 'w-20 h-20 text-4xl',
    md: 'w-32 h-32 text-6xl',
    lg: 'w-44 h-44 text-8xl',
  };

  const equipped_hat     = equipped.find(e => e.item_category === 'hat');
  const equipped_glasses = equipped.find(e => e.item_category === 'glasses');
  const equipped_outfit  = equipped.find(e => e.item_category === 'outfit');

  return (
    <div className={`relative flex flex-col items-center gap-1 ${animate ? 'animate-float' : ''}`}>
      {/* Hat overlay */}
      {equipped_hat && (
        <div className="text-2xl -mb-3 z-10 drop-shadow">
          {ITEM_EMOJI[equipped_hat.item_name] || '🎩'}
        </div>
      )}

      {/* Pet body circle */}
      <div
        className={`${sizeMap[size]} rounded-full flex items-center justify-center relative shadow-lg select-none`}
        style={{ backgroundColor: pet.bg, border: `4px solid ${pet.body}` }}
      >
        {/* Main pet emoji */}
        <span className="relative z-10">{pet.face}</span>

        {/* Glasses overlay */}
        {equipped_glasses && (
          <span className="absolute bottom-2 text-lg">
            {ITEM_EMOJI[equipped_glasses.item_name]}
          </span>
        )}
      </div>

      {/* Mood bubble */}
      <div
        className="absolute -top-2 -right-2 bg-white rounded-full w-8 h-8 flex items-center justify-center text-sm shadow-md border-2 border-gray-100"
        title={`Happiness: ${happiness}%`}
      >
        {getMood()}
      </div>

      {/* Outfit badge */}
      {equipped_outfit && (
        <div className="text-xl -mt-2">
          {ITEM_EMOJI[equipped_outfit.item_name]}
        </div>
      )}

      {/* Level badge */}
      <div className="bg-sprout-yellow text-gray-800 font-black text-xs px-2 py-0.5 rounded-full shadow">
        Lv.{level}
      </div>
    </div>
  );
}
