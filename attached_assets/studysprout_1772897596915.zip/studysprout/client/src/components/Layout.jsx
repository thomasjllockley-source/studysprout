// Layout.jsx — App shell with bottom navigation bar

import { Outlet, useNavigate, useLocation } from 'react-router-dom';

const NAV_ITEMS = [
  { path: '/',         icon: '🏠', label: 'Home' },
  { path: '/start',    icon: '📚', label: 'Study' },
  { path: '/calendar', icon: '📅', label: 'Tests' },
  { path: '/wardrobe', icon: '👗', label: 'Wardrobe' },
];

export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();

  // Hide nav bar during timer and result pages (full focus mode)
  const hideNav = ['/timer', '/result'].includes(location.pathname);

  return (
    <div className="min-h-screen bg-sprout-bg flex flex-col max-w-md mx-auto relative">
      {/* Page content */}
      <main className={`flex-1 overflow-y-auto ${hideNav ? '' : 'pb-24'}`}>
        <Outlet />
      </main>

      {/* Bottom navigation */}
      {!hideNav && (
        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t-2 border-gray-100 flex justify-around px-2 pt-2 pb-4 z-50">
          {NAV_ITEMS.map(({ path, icon, label }) => {
            const active = location.pathname === path;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`flex flex-col items-center gap-0.5 px-4 py-1 rounded-xl transition-all ${
                  active
                    ? 'text-sprout-green'
                    : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <span className={`text-2xl transition-transform ${active ? 'scale-110' : ''}`}>
                  {icon}
                </span>
                <span className={`text-xs font-bold ${active ? 'text-sprout-green' : ''}`}>
                  {label}
                </span>
                {/* Active indicator dot */}
                {active && (
                  <span className="w-1.5 h-1.5 rounded-full bg-sprout-green mt-0.5" />
                )}
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}
