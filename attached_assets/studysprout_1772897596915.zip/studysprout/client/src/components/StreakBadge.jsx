// StreakBadge.jsx — Shows current streak with fire emoji

export default function StreakBadge({ streak = 0 }) {
  if (streak === 0) {
    return (
      <div className="flex items-center gap-1.5 bg-gray-100 rounded-2xl px-4 py-2">
        <span className="text-xl">💤</span>
        <div>
          <p className="text-gray-500 text-xs font-bold">No streak yet</p>
          <p className="text-gray-400 text-xs">Study today to start!</p>
        </div>
      </div>
    );
  }

  const flameColour = streak >= 30 ? '🔥' : streak >= 7 ? '🔥' : '🔥';

  return (
    <div className="flex items-center gap-1.5 bg-orange-50 border-2 border-orange-200 rounded-2xl px-4 py-2">
      <span className="text-2xl animate-bounce">{flameColour}</span>
      <div>
        <p className="text-orange-700 font-black text-lg leading-none">{streak}</p>
        <p className="text-orange-500 text-xs font-bold">day streak!</p>
      </div>
    </div>
  );
}
